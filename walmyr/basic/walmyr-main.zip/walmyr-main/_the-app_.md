# Getting to know the application

Before we start configuring Cypress and writing automated test scripts, let me introduce you to the application we are going to test throughout this course.

The application is called TAT Customer Service Center - [**CAC TAT**](https://cac-tat.s3.eu-central-1.amazonaws.com/index.html) - and was developed using HTML, CSS and JavaScript.

## Application features

The CAC TAT application simulates sending messages to a customer service center.

### Required fields

The following fields must be filled in before being sent:

- Name (text type field)
- Last name (text type field)
- Email (email type field, **with validation**)
- How can we help you? (text area field)

### Other fields

In addition to the mandatory fields, the "customer" can input:

- Phone (number type field)
- Product to be selected (drop-down field with options: Blog, Courses, Mentorship or YouTube)
- Type of service (radio-type fields with options: ​​Help, Praise or Feedback)
- Preferred contact method (checkbox fields with options: Email or Telephone)
- Attachment (user can add a file attachment)

### Rules of preferred means of contact

- When the telephone checkbox is checked, the telephone number input becomes mandatory
- When unchecking the telephone checkbox, the input of the telephone number is no longer mandatory

### Privacy Policy

By clicking on the link [Privacy Policy](https://cac-tat.s3.eu-central-1.amazonaws.com/privacy.html) at the bottom, the page opens in a new browser tab.

### Messages

⚠️ If there is a problem related to the mandatory fields, the following message is displayed with a yellow background: `Validate mandatory fields!`.

✅ When the form is submitted successfully, the following message is displayed with a green background: `Message sent successfully.`.

> Also, when the form is successfully submitted, all fields revert to their default state.

## Your challenge

During the course, I challenge you to test all the features of the CAC TAT application, in addition to setting up a continuous integration pipeline that runs  when changes are sent to GitHub.

I hope you are as eager to get started as I am to guide you along the way! 🧑‍🏫

Go to [lesson 0](./0.md) to setup the test project.
