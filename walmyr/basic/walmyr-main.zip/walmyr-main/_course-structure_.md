# Course structure

## Context and Examples

At the beginning of each lesson, I outline the content to be covered.

> 👨‍🏫 For example: _uploading_ files with Cypress.

In this section, I take more common situations found in the world of web test automation and present Cypress features that solve certain use cases.

> 👨‍🏫 In the above case, I would cite the [`.selectFile()`](https://docs.cypress.io/api/commands/selectfile) functionality, with examples of its usage.
>
> We will see this functionality in detail in [Lesson 6](./06.md).
## Suggested content and links to documentation

In many of the lessons, there are suggested contents with links to official documentation at your fingertips.

## Tips (and _spoilers_ 🙊) from the instructor 👨‍🏫

In some exercises, you will see the instructor emoji (👨‍🏫), or the monkey with its mouth closed (🙊).

When it's the instructor emoji, it's just a reminder.

When it's the monkey emoji, there's some _spoiler_ to help you.

## Exercises

In my opinion, practice is the best way to gain knowledge.

Therefore, at the end of each lesson, there are exercises for you to put the new knowledge into practice.

For each exercise, there is a solution video.

___

Now that you know the structure of the course, go to the [prerequisites](./_pre-requisites_.md) section.
