#    Congratulations, you've made it! 🎉

What a journey, huh?

I hope you enjoyed the course as much as I enjoyed teaching you.

In this same [repository](https://github.com/wlsf82/cypress-basico-v2) you will find solutions for all the exercises in [specific_branches_](https://github.com/wlsf82/cypress-basico-v2/branches), each with their [_commits_](https://github.com/wlsf82/cypress-basico-v2/commits/aula-12), if you want to consult.

Shall we recap what you've learned?

In the Cypress Automated Testing (Basic) course, you learned:

- How to setup a Cypress project from scratch ✔️
- How to visit local and remote pages ✔️
- How to deal with elements most commonly found in web applications ✔️
- How to test _upload_ files ✔️
- How to perform various checks of expected results ✔️
- How to create custom commands ✔️
- How to deal with links that open in another browser tab ✔️
- How to run tests simulating a mobile device ✔️
- How to solve the same problems in different ways, using the [Cypress API](https://docs.cypress.io/api/table-of-contents) ✔️
- How to run tests in a continuous integration _pipeline_  ✔️
- How to create effective documentation for your automated testing project ✔️

Now it's time to put the new knowledge to practice!

Do you want to keep in touch with me? Join the [**Talking About Testing**](https://www.linkedin.com/groups/12492726/) group on LinkedIn and subscribe to [**_Newsletter_ from TAT**](https://mailchimp/6b1f35857228/newsletter-talking-about-testing).

👋 Hope to see you in my [upcoming courses](https://www.udemy.com/user/walmyr/) and good testing! 🚀
